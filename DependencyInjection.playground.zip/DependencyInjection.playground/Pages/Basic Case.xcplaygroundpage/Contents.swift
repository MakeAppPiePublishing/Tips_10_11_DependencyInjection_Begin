//: [Next](@next)

import Foundation

//:# Case 1
//:## Defining Dependency

class Size{
    var height:Double = 10
    var width:Double = 12
}

class Pizza{
    var size = Size()
    func area()-> Double{
        size.height * size.width
    }
}
let pizza = Pizza()
pizza.area()


