//: [Previous](@previous)

//:# Case 2
//:## Dependency Injection
class Size{
    var height:Double = 10
    var width:Double = 12
    init(height:Double, width:Double){
        self.height = height
        self.width = width
    }
}

class Pizza{
    var size:Size?
    func area()-> Double{
        (size?.height ?? 0)  * (size?.width ?? 0)
    }
}


let pizza = Pizza()

pizza.area()

